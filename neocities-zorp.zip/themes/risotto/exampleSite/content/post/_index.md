+++
aliases = ["posts", "articles", "blog", "showcase", "docs"]
title = "Posts"
author = "Hugo Authors"
description = "Example posts demonstrating hugo's markup features"
tags = ["index"]
+++
