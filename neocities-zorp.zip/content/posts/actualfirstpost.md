---
title: "Actually the first post"
date: 2024-09-29T13:12:21-04:00
slug: 2024-09-29-actualfirstpost
type: posts
draft: false
categories:
  - blog
tags:
  - default
---
Hello, Welcome, I finally got hugo to work.
Trust me I wish I had a better theme but that is basically not an option at this point. I had to resist bashing my head into 
the computer yesterday. It seems this is the only properly configured Hugo theme. Thanks to the people/person that made smol
because it really simplifies writing content. I don't mind having a simple site but blogging right in my html seems dangerous and it 
tempts me to code. This way I can just focus on content and push it to neocities very easily. with the command "neocities push (the path to the public folder on hugo.)"
I did accedentally delete my other index.html that I spent at least 10hrs on (whoops...) but It was a janky vanilla html mess of hotlinked everything.
It would not have lasted another year without a serious rennovation. this was easier.
