---
title: "Full Workflow Vid Coming Soon"
date: 2024-09-30T20:10:48-04:00
slug: 2024-09-30-full-workflow-vid-coming-soon
type: posts
draft: false
categories:
  - default
tags:
  - default
---
I'm working on a video that shows off the bash script that I wrote that automatically cds and hugo create news etc etc. all the way down to opening nano
with the new file i made open. It's also the first bash script I have ever made so I probably failed to make it "bashic" (pythonic for bash)
anyway, stay tuned.
